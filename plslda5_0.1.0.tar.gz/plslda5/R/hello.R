hello <- function() {
  print(hello)
}
